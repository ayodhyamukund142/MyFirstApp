
import xbmcaddon
import os
import time

#import StringIO
#import cProfile
#import pstats
from common import GLOBAL_SETUP  #Needed first to setup import locations
import mezzmo

mezzmo.start()

#sys.modules.clear()
